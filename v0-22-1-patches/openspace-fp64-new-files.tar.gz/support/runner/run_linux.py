#!/usr/bin/env python3
##########################################################################################
#                                                                                        #
# OpenSpace Visual Testing - Linux Runner & MRF Cache Warmer                             #
#                                                                                        #
# Copyright (c) 2024-2026                                                                #
#                                                                                        #
# Permission is hereby granted, free of charge, to any person obtaining a copy of this   #
# software and associated documentation files (the "Software"), to deal in the Software  #
# without restriction, including without limitation the rights to use, copy, modify,     #
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to     #
# permit persons to whom the Software is furnished to do so, subject to the following    #
# conditions:                                                                            #
#                                                                                        #
# The above copyright notice and this permission notice shall be included in all copies  #
# or substantial portions of the Software.                                               #
#                                                                                        #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,    #
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A          #
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT     #
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF   #
# CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE   #
# OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.                                          #
##########################################################################################

import argparse
import asyncio
import datetime
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

# Ensure testsuite package can be imported if this script is executed from anywhere
runner_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(runner_dir))

try:
  from openspace import Api
except ImportError:
  Api = None

from testsuite.instruction import Instruction
from testsuite.test import Test, TestResult


def write_configuration_overwrite(base_path: Path, data_path: Path) -> None:
  """Creates openspace.cfg.override pointing SYNC and MRFCache to custom data path."""
  with open(base_path / "openspace.cfg.override", "w") as f:
    sync_location = (data_path / "sync").as_posix()
    f.write(f"Paths.SYNC = os.getenv([[OPENSPACE_SYNC]]) or [[{sync_location}]]\n")

    mrf_location = (data_path / "mrf").as_posix()
    f.write("ModuleConfigurations.GlobeBrowsing.MRFCacheEnabled = true\n")
    f.write(f"ModuleConfigurations.GlobeBrowsing.MRFCacheLocation = [[{mrf_location}]]\n")

    f.write("ModuleConfigurations.CefWebGui.Enabled = false\n")
    f.write("Server.Interfaces[2].Enabled = false\n")
    f.write("VersionCheckUrl = [[]]\n")
    f.write("CheckOpenGLState = true\n")


async def setup_test_run(openspace: Any) -> None:
  """Setup settings common to all test runs (pause time, hide overlays)."""
  await openspace.time.setPause(True)
  await openspace.setPropertyValueSingle("Dashboard.IsEnabled", False)
  await openspace.setPropertyValueSingle("RenderEngine.ShowLog", False)
  await openspace.setPropertyValueSingle("RenderEngine.ShowVersion", False)
  await openspace.setPropertyValueSingle("RenderEngine.ShowCamera", False)


def find_openspace_root(custom_root: str | None = None) -> Path:
  """Locate the OpenSpace repository root directory."""
  if custom_root:
    p = Path(custom_root).resolve()
    if p.is_dir() and (p / "visualtests").is_dir():
      return p

  # Check standard parent hierarchy: <root>/support/runner/run_linux.py
  candidate = runner_dir.parents[1]
  if (candidate / "visualtests").is_dir():
    return candidate

  # Check current working directory
  cwd = Path.cwd().resolve()
  if (cwd / "visualtests").is_dir():
    return cwd
  if (cwd / "OpenSpace" / "visualtests").is_dir():
    return cwd / "OpenSpace"

  # Fallback: check environment variable
  env_dir = os.environ.get("OPENSPACE_DIR")
  if env_dir:
    p = Path(env_dir).resolve()
    if (p / "visualtests").is_dir():
      return p

  return candidate


async def connect_to_openspace(host: str = "localhost", port: int = 4681,
                               timeout: float = 60.0) -> tuple[Any, Any]:
  """Connect to the OpenSpace API, retrying until OpenSpace is ready."""
  if Api is None:
    raise SystemExit(
      "ERROR: The 'openspace-api' Python package is not installed.\n"
      "Please install it using: pip install openspace-api"
    )

  print(f"Connecting to OpenSpace API at {host}:{port} (timeout: {timeout}s)...")
  start_time = time.time()
  last_err = None

  while time.time() - start_time < timeout:
    try:
      os_api = Api(host, port)
      await os_api.connect()
      openspace = await os_api.library()
      print(f"  Connected to OpenSpace successfully ({time.time() - start_time:.1f}s)")
      return os_api, openspace
    except Exception as e:
      last_err = e
      await asyncio.sleep(1.0)

  raise RuntimeError(
    f"Failed to connect to OpenSpace at {host}:{port} after {timeout} seconds. "
    f"Last error: {last_err}"
  )


def store_image(result: TestResult, file: str, index: int = 0, total_files: int = 1,
                output_base: Path = Path("tests"), move: bool = True) -> None:
  """
  Stores the screenshot for the test. If move is True, the file is moved out of the
  temporary screenshots folder to keep it clean. If total_files > 1, unique suffixes
  are used so multiple images from the same test do not overwrite each other.
  """
  dest_folder = output_base / result.group
  dest_folder.mkdir(parents=True, exist_ok=True)
  if total_files > 1:
    destination = dest_folder / f"{result.name}_{index}.png"
  else:
    destination = dest_folder / f"{result.name}.png"

  action = "Moving" if move else "Copying"
  print(f"  {action} screenshot: {file} -> {destination}")
  if move:
    shutil.move(file, destination)
  else:
    shutil.copy(file, destination)


def submit_image(result: TestResult, hardware: str, timestamp: str, file: str,
                 runner: str, url: str) -> None:
  try:
    import requests
  except ImportError:
    print("Cannot submit image: 'requests' module is not installed.")
    return

  with open(file, "rb") as f:
    res = requests.post(
      url,
      data={
        "group": result.group,
        "name": result.name,
        "hardware": hardware,
        "runnerID": runner,
        "timestamp": timestamp,
        "timing": result.timing,
        "commitHash": result.commit,
      },
      files={"file": f, "log": result.error},
    )
  if res.status_code == 200:
    print(f"Image submitted successfully: {result.group} / {result.name}")
  else:
    print(f"Image submission failed with error {res.status_code}: {res.text}")


async def execute_test_instructions(openspace: Any, os_api: Any, test: Test,
                                    dry_run: bool = False) -> None:
  """Run instructions of a single test. In dry-run mode, screenshot instructions are skipped."""
  for instruction in test.instructions:
    if dry_run and instruction.is_screenshot:
      print("    [Dry-run] Skipping screenshot")
      continue

    await instruction.run(openspace, os_api)
    await asyncio.sleep(1.0)


async def dry_run_suite(tests: list[Test], executable_cmd: str, profile: str,
                        root_dir: Path, sgct_config: Path | None,
                        attach: bool = False, auto_clean_assets: bool = True) -> None:
  """
  Executes all provided tests using a SINGLE OpenSpace instance.
  Screenshots are skipped, allowing the user to view the scene and let MRF/GlobeBrowsing
  tiles populate the cache before proceeding to the next test.
  """
  process = None
  launch_instance = not attach

  if launch_instance:
    print("\n" + "=" * 80)
    print(f"Starting OpenSpace in single-instance mode (Profile: '{profile}')")
    print(f"Command: {executable_cmd}")
    print("=" * 80)

    cmd = [executable_cmd, "--profile", profile, "--bypassLauncher"]
    if sgct_config and sgct_config.is_file():
      cmd.extend(["--config", str(sgct_config)])

    process = subprocess.Popen(
      cmd,
      cwd=str(root_dir),
      stdout=subprocess.DEVNULL,
      stderr=subprocess.PIPE
    )

  try:
    os_api, openspace = await connect_to_openspace(timeout=60.0)

    total = len(tests)
    for idx, test in enumerate(tests, start=1):
      print("\n" + "=" * 80)
      print(f"[{idx}/{total}] DRY-RUN TEST: {test.group} / {test.name}")
      print(f"  File:    {test.test_path}")
      print(f"  Profile: {test.profile}")
      print("=" * 80)

      # Basic setup (pause time, hide overlays)
      await setup_test_run(openspace)

      # Extract assets added by this test so we can cleanly unload them
      added_assets = [
        inst.value for inst in test.instructions
        if inst.instruction_type == "asset" and isinstance(inst.value, str)
      ]

      # Execute instructions
      await execute_test_instructions(openspace, os_api, test, dry_run=True)

      print("\n>>> Instructions executed successfully!")
      print(">>> Scene is live in OpenSpace. Streaming / downloading MRF tiles into cache...")

      # Interactive pause for user
      while True:
        try:
          prompt = (
            f"\n[Test {idx}/{total}: {test.name}]\n"
            "  Press [Enter] when tiles are loaded to proceed to next test\n"
            "  'r' + [Enter]: remove added assets & continue\n"
            "  's' + [Enter]: skip asset removal and continue\n"
            "  'q' + [Enter]: stop dry-run and exit\n"
            "Choice: "
          )
          choice = input(prompt).strip().lower()
        except (KeyboardInterrupt, EOFError):
          choice = 'q'

        if choice in ('', 'r'):
          # Clean up assets added by this test so next test starts clean
          if auto_clean_assets or choice == 'r':
            print("  Cleaning up test assets from scene graph...")
            for asset_name in added_assets:
              try:
                await openspace.asset.remove(asset_name)
              except Exception:
                pass
            try:
              # Fallback: remove all root assets if empty profile
              if profile == "empty":
                await openspace.asset.removeAll()
            except Exception:
              pass
          break
        elif choice == 's':
          print("  Retaining assets in scene graph.")
          break
        elif choice == 'q':
          print("\nExiting dry-run mode early upon user request.")
          return
        else:
          print("Unknown option. Press Enter, 'r', 's', or 'q'.")

    print("\n" + "=" * 80)
    print(f"All {total} dry-run tests completed! MRF cache populated.")
    print("=" * 80)

  finally:
    if launch_instance and process:
      try:
        should_close = input("\nDry-run complete. Close OpenSpace window now? [Y/n]: ").strip().lower()
        if should_close not in ('n', 'no'):
          print("Shutting down OpenSpace...")
          try:
            await openspace.toggleShutdown(0.25)
            await asyncio.sleep(2)
          except Exception:
            pass
          process.terminate()
          process.wait(timeout=5)
        else:
          print("Leaving OpenSpace running in background.")
      except Exception:
        if process.poll() is None:
          process.kill()


def run_regular_suite(tests: list[Test], executable_cmd: str, root_dir: Path,
                      sgct_config: Path | None, attach: bool,
                      submit_images: bool, hardware: str, runner_id: str,
                      submit_url: str, per_profile_wait: dict[str, int],
                      keep_temp: bool = False, clean_assets: bool = True) -> None:
  """Run tests individually with screenshots, opening and closing OpenSpace for each test."""
  total = len(tests)
  for idx, test in enumerate(tests, start=1):
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print("\n" + "=" * 80)
    print(f"[{idx}/{total}] RUNNING TEST: {test.group} / {test.name}")
    print(f"  File:    {test.test_path}")
    print(f"  Profile: {test.profile}")
    print("=" * 80)

    if test.skip_test:
      print("  Skipping test as requested by ostest definition.")
      continue

    start_time = time.perf_counter()
    process = None
    launch_process = not attach

    if launch_process:
      cmd = [executable_cmd, "--profile", test.profile, "--bypassLauncher"]
      if sgct_config and sgct_config.is_file():
        cmd.extend(["--config", str(sgct_config)])

      process = subprocess.Popen(
        cmd,
        cwd=str(root_dir),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE
      )

      # Wait timer or connection polling
      wait_time = per_profile_wait.get(test.profile, 5)
      time.sleep(wait_time)

    async def single_loop():
      os_api, openspace = await connect_to_openspace(timeout=60.0)

      # 1. Resolve screenshot folder and snapshot existing screenshots before test execution
      screenshot_folder_str = await openspace.absPath("${SCREENSHOTS}")
      screenshot_folder = Path(screenshot_folder_str)
      screenshot_folder.mkdir(parents=True, exist_ok=True)
      pre_existing_screenshots = set(screenshot_folder.glob("*.png"))
      test_start_ts = time.time()

      print("  Setting up test environment...")
      await setup_test_run(openspace)
      print("  Executing test commands...")
      await test.run(openspace, os_api)

      # 2. Wait for newly created screenshot(s) to be written to disk
      new_screenshots = []
      for _ in range(30):  # poll for up to 6 seconds
        current = set(screenshot_folder.glob("*.png"))
        diff = current - pre_existing_screenshots
        if diff:
          new_screenshots = sorted(list(diff), key=lambda p: p.stat().st_mtime)
          break
        await asyncio.sleep(0.2)

      # Fallback: check by modification time if filename collided or was overwritten
      if not new_screenshots:
        new_screenshots = [
          p for p in screenshot_folder.glob("*.png")
          if p.stat().st_mtime >= test_start_ts - 1.0
        ]

      version_info = await openspace.version()
      commit = version_info.get("Commit", "")

      if launch_process:
        print("  Closing OpenSpace instance...")
        await openspace.toggleShutdown(0.25)
      elif clean_assets:
        # In attached mode with multiple tests, reset root assets so the next test
        # runs in a clean scene graph
        try:
          await openspace.asset.removeAll()
        except Exception:
          pass

      os_api.disconnect()
      await asyncio.sleep(0)
      return [str(p) for p in new_screenshots], commit

    loop = asyncio.new_event_loop()
    try:
      new_screenshot_files, commit = loop.run_until_complete(single_loop())
    finally:
      loop.close()
      if launch_process and process:
        time.sleep(3)
        error_log = ""
        if process.stderr:
          try:
            error_log = process.stderr.read().decode(errors="replace")
          except Exception:
            error_log = "Error reading stderr"
        if process.poll() is None:
          process.kill()
          process.wait()
      else:
        error_log = ""

    end_time = time.perf_counter()
    duration = end_time - start_time

    print(f"  Test completed in {duration:.2f}s. Captured {len(new_screenshot_files)} new screenshot(s).")

    result = TestResult(
      group=test.group,
      name=test.name,
      files=new_screenshot_files,
      timing=duration,
      commit=commit,
      error=error_log
    )

    total_files = len(new_screenshot_files)
    for idx_img, img in enumerate(new_screenshot_files):
      if submit_images:
        submit_image(result, hardware, timestamp, img, runner_id, submit_url)
      store_image(result, img, index=idx_img, total_files=total_files, move=not keep_temp)

    time.sleep(2.0)


def main():
  parser = argparse.ArgumentParser(
    description="OpenSpace Visual Test Runner for Linux (supports native 'openspace' wrapper and MRF cache warm-up)"
  )
  parser.add_argument(
    "-t", "--test",
    dest="test",
    type=str,
    help="Comma-separated list of tests to run (e.g. 'default/earth,misc/atmopshere/earth-outside'). "
         "Omit to run all discovered tests."
  )
  parser.add_argument(
    "-p", "--profile",
    dest="profile",
    type=str,
    default=None,
    help="Filter tests by required profile (e.g. 'empty', 'default')."
  )
  parser.add_argument(
    "--dry-run-empty",
    action="store_true",
    help="Shortcut: Run all tests with profile 'empty' in single-instance dry-run mode (no screenshots, "
         "keeps OpenSpace open, prompts user between tests to fill up MRF cache)."
  )
  parser.add_argument(
    "--dry-run",
    action="store_true",
    help="Run selected tests in dry-run mode (no screenshots, keeps OpenSpace open across tests sharing the profile)."
  )
  parser.add_argument(
    "-a", "--attach",
    action="store_true",
    help="Connect to an already running OpenSpace instance rather than launching new processes."
  )
  parser.add_argument(
    "-e", "--executable",
    dest="executable",
    type=str,
    default="openspace",
    help="Command or path used to launch OpenSpace on Linux (default: 'openspace')."
  )
  parser.add_argument(
    "-o", "--overwrite",
    dest="overwrite_path",
    type=str,
    help="Base path for shared cache directories (writes openspace.cfg.override for SYNC and MRF cache)."
  )
  parser.add_argument(
    "--root",
    dest="root_dir",
    type=str,
    help="Explicit root directory of the OpenSpace repository."
  )
  parser.add_argument(
    "--no-clean",
    action="store_true",
    help="In dry-run or attached mode, do not remove root assets between consecutive tests."
  )
  parser.add_argument(
    "--keep-temp",
    action="store_true",
    help="Keep original screenshots in OpenSpace's ${SCREENSHOTS} folder instead of moving them to tests/."
  )

  args = parser.parse_args()

  root_dir = find_openspace_root(args.root_dir)
  visualtests_dir = root_dir / "visualtests"
  if not visualtests_dir.is_dir():
    raise SystemExit(f"Could not find 'visualtests' directory in '{root_dir}'. Use --root to specify it.")

  print(f"OpenSpace Root:       {root_dir}")
  print(f"Visual Tests Directory: {visualtests_dir}")
  print(f"OpenSpace Executable: {args.executable}")

  # Check SGCT window configuration
  sgct_config = runner_dir / "1920-1080.json"
  if not sgct_config.is_file():
    sgct_config = None

  # Handle overwrite configuration if requested
  if args.overwrite_path:
    print(f"Writing configuration override pointing to cache: {args.overwrite_path}")
    write_configuration_overwrite(root_dir, Path(args.overwrite_path))

  # Discover and filter test files
  if args.test:
    test_names = [t.strip() for t in args.test.split(",") if t.strip()]
    test_files = []
    for name in test_names:
      # Support path ending with .ostest, or relative group/name
      if name.endswith(".ostest") and Path(name).is_file():
        test_files.append(Path(name))
      else:
        candidate = visualtests_dir / f"{name}.ostest"
        if candidate.is_file():
          test_files.append(candidate)
        else:
          # Try case-insensitive or recursive search
          matches = list(visualtests_dir.rglob(f"{Path(name).name}.ostest"))
          if matches:
            test_files.append(matches[0])
          else:
            raise SystemExit(f"Could not locate visual test '{name}' in {visualtests_dir}")
  else:
    test_files = sorted(visualtests_dir.rglob("*.ostest"))

  # Load Test objects
  all_tests = [Test(f) for f in test_files]

  # Apply profile filtering
  target_profile = "empty" if args.dry_run_empty else args.profile
  if target_profile:
    all_tests = [t for t in all_tests if t.profile.lower() == target_profile.lower()]

  if not all_tests:
    print("No matching visual tests found.")
    return

  print(f"Total tests selected: {len(all_tests)}")

  # Check regression server config.json
  config_path = runner_dir / "config.json"
  submit_images = False
  submit_url, hardware, runner_id = "", "", ""
  per_profile_wait = {}

  if config_path.is_file() and not (args.dry_run or args.dry_run_empty):
    with open(config_path) as f:
      conf = json.load(f)
      submit_url = f"{conf['url']}/api/submit-test"
      hardware = conf.get("hardware", "Linux")
      runner_id = conf.get("id", "")
      per_profile_wait = conf.get("per-profile-wait", {})
      submit_images = True
      print(f"Regression Server: {submit_url} (Hardware: {hardware})")

  # Dispatch execution
  is_dry_run = args.dry_run or args.dry_run_empty
  if is_dry_run:
    chosen_profile = target_profile or all_tests[0].profile
    asyncio.run(
      dry_run_suite(
        tests=all_tests,
        executable_cmd=args.executable,
        profile=chosen_profile,
        root_dir=root_dir,
        sgct_config=sgct_config,
        attach=args.attach,
        auto_clean_assets=not args.no_clean
      )
    )
  else:
    run_regular_suite(
      tests=all_tests,
      executable_cmd=args.executable,
      root_dir=root_dir,
      sgct_config=sgct_config,
      attach=args.attach,
      submit_images=submit_images,
      hardware=hardware,
      runner_id=runner_id,
      submit_url=submit_url,
      per_profile_wait=per_profile_wait,
      keep_temp=args.keep_temp,
      clean_assets=not args.no_clean
    )


if __name__ == "__main__":
  main()
