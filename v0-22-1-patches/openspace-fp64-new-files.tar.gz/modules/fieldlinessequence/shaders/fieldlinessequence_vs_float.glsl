/*****************************************************************************************
 *                                                                                       *
 * OpenSpace                                                                             *
 *                                                                                       *
 * Copyright (c) 2014-2026                                                               *
 *                                                                                       *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this  *
 * software and associated documentation files (the "Software"), to deal in the Software *
 * without restriction, including without limitation the rights to use, copy, modify,    *
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to    *
 * permit persons to whom the Software is furnished to do so, subject to the following   *
 * conditions:                                                                           *
 *                                                                                       *
 * The above copyright notice and this permission notice shall be included in all copies *
 * or substantial portions of the Software.                                              *
 *                                                                                       *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,   *
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A         *
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT    *
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF  *
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE  *
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.                                         *
 ****************************************************************************************/

#version __CONTEXT__

layout(location = 0) in vec3 in_position;
layout(location = 1) in float in_color;
layout(location = 2) in float in_masking;

out Data {
  vec4 color;
  float depth;
} out_data;

uniform mat4 modelViewProjection;

// Color Uniforms
uniform vec4 lineColor;
uniform int colorMethod;
uniform sampler1D transferFunction;
uniform vec2 selectedColorRange;

// Flow / Particles Uniforms
uniform vec4 flowColor;
uniform int particleSize;
uniform int particleSpeed;
uniform int particleSpacing;
uniform float time;
uniform bool usingParticles;

// Masking Uniforms
uniform bool usingMasking;
uniform vec2 maskingRange;

// Domain Uniforms
uniform bool usingDomain;
uniform vec2 domainLimX;
uniform vec2 domainLimY;
uniform vec2 domainLimZ;
uniform vec2 domainLimR;

// These should correspond to the enum 'ColorMethod' in renderablefieldlinesequence.cpp
const int ColorMethodUniformColor = 0;
const int ColorMethodColorByQuantity = 1;

vec4 transferFunctionColor() {
  float lookUpVal = (in_color - selectedColorRange.x) /
                    (selectedColorRange.y - selectedColorRange.x);
  return texture(transferFunction, lookUpVal);
}

bool isPartOfParticle(float time, int vertexId, int particleSize, int particleSpeed,
                      int particleSpacing)
{
  int modulusResult = int(float(particleSpeed) * time + float(vertexId)) % particleSpacing;
  return modulusResult > 0 && modulusResult <= particleSize;
}

void main() {
  bool hasColor = true;

  if (usingMasking && (in_masking < maskingRange.x || in_masking > maskingRange.y)) {
    hasColor = false;
  }

  if (usingDomain && hasColor) {
    float radius = length(in_position);
    vec3 lowerLimit = vec3(domainLimX.x, domainLimY.x, domainLimZ.x);
    vec3 upperLimit = vec3(domainLimX.y, domainLimY.y, domainLimZ.y);
    if (any(lessThan(in_position, lowerLimit)) ||
        any(lessThan(in_position, upperLimit)) ||
        radius < domainLimR.x || radius > domainLimR.y)
    {
      hasColor = false;
    }
  }

  if (hasColor) {
    bool isParticle = usingParticles &&
      isPartOfParticle(time, gl_VertexID, particleSize, particleSpeed, particleSpacing);
    out_data.color = isParticle ? flowColor : lineColor;

    if (colorMethod == ColorMethodColorByQuantity) {
      vec4 quantityColor = transferFunctionColor();
      out_data.color = vec4(quantityColor.xyz, out_data.color.a * quantityColor.a);
    }
  }
  else {
    out_data.color = vec4(0.0);
  }

  vec4 positionClipSpace = modelViewProjection * vec4(in_position, 1.0);
  gl_Position = vec4(positionClipSpace.xy, 0, positionClipSpace.w);
  out_data.depth = gl_Position.w;
}
